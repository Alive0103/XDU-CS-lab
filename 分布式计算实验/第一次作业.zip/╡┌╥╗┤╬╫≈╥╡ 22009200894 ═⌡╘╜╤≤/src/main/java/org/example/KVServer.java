package org.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.*;
import java.util.concurrent.*;
import java.util.concurrent.ConcurrentHashMap;

public class KVServer {
    private static final ConcurrentHashMap<String, String> store = new ConcurrentHashMap<>();

    public static void main(String[] args) throws Exception {
        // 使用固定大小的线程池（避免资源耗尽）
        ExecutorService pool = Executors.newFixedThreadPool(100);
        try (ServerSocket server = new ServerSocket(8080)) {
            while (true) {
                Socket client = server.accept();
                pool.execute(new ClientHandler(client));
            }
        }
    }

    static class ClientHandler implements Runnable {
        private final Socket client;

        public ClientHandler(Socket socket) { this.client = socket; }

        public void run() {
            try (BufferedReader in = new BufferedReader(
                    new InputStreamReader(client.getInputStream()));
                 PrintWriter out = new PrintWriter(client.getOutputStream(), true)) {

                String input;
                while ((input = in.readLine()) != null) {
                    String[] cmd = input.split(" ");
                    switch (cmd[0].toUpperCase()) {
                        case "PUT":
                            if (cmd.length >= 3) {
                                store.put(cmd[1], cmd[2]);
                                out.println("OK");
                                out.flush();        // 强制刷新缓冲区
                            } else {
                                out.println("ERROR: PUT requires key and value");
                            }
                            break;
                        case "GET":
                            out.println(store.getOrDefault(cmd[1], "NULL"));
                            break;
                        case "DELETE":
                            store.remove(cmd[1]);
                            out.println("DELETED");
                            break;
                        case "EXIT":
                            client.close();
                            return;
                        default:
                            out.println("Invalid Command");
                    }
                }
            } catch (IOException e) { /* 异常处理 */ }
        }
    }
}