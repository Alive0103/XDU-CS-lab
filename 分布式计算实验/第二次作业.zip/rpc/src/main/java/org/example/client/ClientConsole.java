package org.example.client;

import org.apache.thrift.TException;
import org.example.Appointment;
import org.example.HospitalService;


import java.util.List;
import java.util.Scanner;

public class ClientConsole {
    private static final Scanner scanner = new Scanner(System.in);
    private static HospitalService.Client client;

    public static void main(String[] args) {
        // 初始化Thrift连接
        client = HospitalClient.connect();
        if (client == null) {
            System.err.println("无法连接到服务器");
            return;
        }

        // 主交互循环
        while (true) {
            showMainMenu();
            processUserChoice();
        }
    }

    private static void showMainMenu() {
        System.out.println("\n=== 西电医院智能预约系统 ===");
        System.out.println("1. 新建预约\t2. 按ID查询");
        System.out.println("3. 按姓名查询\t4. 取消预约");
        System.out.println("0. 退出系统");
        System.out.print("请输入操作编号：");
    }

    private static void processUserChoice() {
        try {
            int choice = readIntInput();
            scanner.nextLine(); // 清除输入缓冲区

            switch (choice) {
                case 1:
                    createAppointment();
                    break;
                case 2:
                    queryById();
                    break;
                case 3:
                    queryByName();
                    break;
                case 4:
                    cancelAppointment();
                    break;
                case 0:
                    exitSystem();
                    break;
                default:
                    System.out.println("无效的操作编号，请重新输入");
            }
        } catch (Exception e) {
            handleException(e);
        }
    }

    // 功能模块一：新建预约
    private static void createAppointment() throws TException {
        System.out.println("\n--- 新建预约 ---");
        Appointment request = collectAppointmentInfo();

        try {
            Appointment result = client.bookAppointment(request);
            System.out.printf("预约成功！ID: %d\n", result.getId());
        } catch (TException e) {
            System.err.println("预约失败: " + e.getMessage());
        }
    }

    // 功能模块二：按ID查询
    private static void queryById() throws TException {
        System.out.println("\n--- 按ID查询 ---");
        System.out.print("请输入预约ID：");
        int id = readIntInput();

        Appointment found = client.queryByAppointmentID(id);
        displayAppointment(found, "未找到该预约记录");
    }

    // 功能模块三：按姓名查询
    private static void queryByName() throws TException {
        System.out.println("\n--- 按姓名查询 ---");
        System.out.print("请输入患者姓名：");
        String name = scanner.nextLine().trim();

        List<Appointment> results = client.queryByPatientName(name);
        displayResults(results);
    }

    // 功能模块四：取消预约
    private static void cancelAppointment() throws TException {
        System.out.println("\n--- 取消预约 ---");
        System.out.print("请输入要取消的预约ID：");
        int id = readIntInput();

        boolean success = client.cancelAppointment(id);
        System.out.println(success ? "取消成功" : "取消失败（ID不存在或已完成）");
    }

    // 工具方法：收集预约信息
    private static Appointment collectAppointmentInfo() {
        System.out.print("患者姓名：");
        String patient = scanner.nextLine().trim();

        System.out.print("医生姓名：");
        String doctor = scanner.nextLine().trim();

        System.out.print("科室名称：");
        String dept = scanner.nextLine().trim();

        System.out.print("预约日期（格式：YYYY-MM-DD）：");
        String date = scanner.nextLine().trim();

        System.out.print("时间段（示例：09:00-10:00）：");
        String time = scanner.nextLine().trim();

        return new Appointment()
                .setPatientName(patient)
                .setDoctorName(doctor)
                .setDepartment(dept)
                .setDate(date)
                .setTimeSlot(time);
    }

    // 工具方法：显示单个预约
    private static void displayAppointment(Appointment appt, String notFoundMsg) {
        if (appt != null) {
            System.out.println("┌──────────────── 预约详情 ────────────────");
            System.out.printf("│ ID：%d%n", appt.getId());
            System.out.printf("│ 患者：%s%n", appt.getPatientName());
            System.out.printf("│ 医生：%s%n", appt.getDoctorName());
            System.out.printf("│ 科室：%s%n", appt.getDepartment());
            System.out.printf("│ 时间：%s %s%n", appt.getDate(), appt.getTimeSlot());
            System.out.println("└───────────────────────────────────────");
        } else {
            System.out.println(notFoundMsg);
        }
    }

    // 工具方法查询结果集
    private static void displayResults(List<Appointment> apps) {
        if (apps == null || apps.isEmpty()) {
            System.out.println("未找到相关预约记录");
            return;
        }

        System.out.println("┌─────── 查询结果（共" + apps.size() + "条）───────");
        apps.forEach(appt ->
                System.out.printf("│ %d | %s | %s%n",
                        appt.getId(),
                        appt.getPatientName(),
                        appt.getDate() + " " + appt.getTimeSlot())
        );
        System.out.println("└───────────────────────────────────────");
    }

    // 工具方法：安全读取整型输入
    private static int readIntInput() {
        while (true) {
            try {
                return scanner.nextInt();
            } catch (Exception e) {
                System.out.print("输入格式错误，请重新输入数字：");
                scanner.nextLine(); // 清除错误输入
            }
        }
    }

    // 异常统一处理
    private static void handleException(Exception e) {
        System.err.println("\n⚠️ 系统发生异常：");
        if (e instanceof TException) {
            System.err.println("服务连接异常，请检查：");
            System.err.println("1. 服务端是否已启动");
            System.err.println("2. 网络连接是否正常");
        } else {
            e.printStackTrace();
        }
        System.err.println("即将返回主菜单...");
    }

    // 系统退出处理
    private static void exitSystem() {
        System.out.println("\n感谢使用西电医院预约系统，再见！");
        scanner.close();
        System.exit(0);
    }
}