package org.example.client;

import org.apache.thrift.transport.TSocket;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.transport.TTransport;
import org.example.HospitalService;


public class HospitalClient {
    public static HospitalService.Client connect() {
        try {
            TTransport transport = new TSocket("localhost", 9090);
            transport.open();
            return new HospitalService.Client(new TBinaryProtocol(transport));
        } catch (Exception e) {
            System.err.println("连接西电医院服务器失败: " + e.getMessage());
            return null;
        }
    }
}