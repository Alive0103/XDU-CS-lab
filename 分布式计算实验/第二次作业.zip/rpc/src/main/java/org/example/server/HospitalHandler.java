package org.example.server;

import org.example.Appointment;
import org.example.HospitalService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class HospitalHandler implements HospitalService.Iface {
    private static final Logger log = LoggerFactory.getLogger(HospitalHandler.class);
    private final ConcurrentHashMap<Integer, Appointment> appointments = new ConcurrentHashMap<>();
    private final AtomicInteger idGenerator = new AtomicInteger(1);

    @Override
    public Appointment bookAppointment(Appointment appointment)  {
        // 生成新ID并创建副本
        int newId = idGenerator.getAndIncrement();
        Appointment newAppt = new Appointment(appointment)
                .setId(newId);

        // 存储到数据库
        appointments.put(newId, newAppt);
        System.out.printf("服务端生成ID：%d", newId);

        return newAppt; // 返回包含新ID的对象
    }

    @Override
    public Appointment queryByAppointmentID(int appointmentID) {
        return appointments.get(appointmentID);
    }

    @Override
    public List<Appointment> queryByPatientName(String patientName) {
        List<Appointment> result = new ArrayList<>();
        for (Appointment appt : appointments.values()) {
            if (appt.getPatientName().equals(patientName)) {
                result.add(appt);
            }
        }
        return result;
    }

    @Override
    public boolean cancelAppointment(int appointmentID) {
        return appointments.remove(appointmentID) != null;
    }
}