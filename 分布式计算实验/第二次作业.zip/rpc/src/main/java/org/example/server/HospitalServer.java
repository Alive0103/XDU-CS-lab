package org.example.server;

import org.apache.thrift.server.TServer;
import org.apache.thrift.server.TSimpleServer;
import org.apache.thrift.transport.TServerSocket;
import org.apache.thrift.transport.TServerTransport;
import org.example.HospitalService;

public class HospitalServer {
    public static void main(String[] args) {
        try {
            HospitalHandler handler = new HospitalHandler();
            HospitalService.Processor<HospitalHandler> processor =
                    new HospitalService.Processor<>(handler);

            TServerTransport serverTransport = new TServerSocket(9090);
            TServer server = new TSimpleServer(
                    new TServer.Args(serverTransport).processor(processor));

            System.out.println("西电医院挂号系统服务端已启动...");
            server.serve();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}