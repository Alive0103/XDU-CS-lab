namespace java org.example

struct Appointment {
    1: required i32 id,
    2: string patientName,
    3: string doctorName,
    4: string department,
    5: string date,
    6: string timeSlot
}

service HospitalService {
    Appointment bookAppointment(1: Appointment appointment),
    Appointment queryByAppointmentID(1: i32 appointmentID),
    list<Appointment> queryByPatientName(1: string patientName),
    bool cancelAppointment(1: i32 appointmentID)
}