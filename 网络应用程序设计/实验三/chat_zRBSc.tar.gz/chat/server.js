//---收到连接后向client要名字，第一次收到数据是名字mynameisXXX
var WebSocketServer = require('ws').Server;
var wss = new WebSocketServer({ port: 8016 });
const sd=require('silly-datetime');

let clients = [];  //记录客户端对象  
let i =0; //记录客户端 序号

//绑定事件connection，此事件是当有客户端连接时，触发
wss.on('connection', function (ws,request) { //ws就是连接的客户端对象
        ws.name = ''; 
        clients.push(ws); //把客户端对象保存起来
        console.log('聊天室内共'+clients.length+'个人');
    //var cc=document.cookie;
        //给客户端对象绑定事件message，当客户端发送信息时，触发该事件
        ws.on('message', function (message) { //给客户端对象绑定message事件，有信息发过来了。
            var msg=message.toString();
            if(msg.indexOf('mynameis:')==0 && msg.length>'mynameis:'.length) 
            {
                ws.name=msg.replace("mynameis:","");
                broadcast0(ws.name+'进入聊天室', ws); //把客户端发送来的信息，广播给其它客户端。 
            }
            else
                broadcast(message, ws); //把客户端发送来的信息，广播给其它客户端。 
        });
    
/*        ws.on('close', function () { //给客户端对象绑定close事件，客户端关闭了
            clients.forEach((item,index,clients) => {
                    if(item[0] === ws)
                    {
                        clients.splice(index,1);
                        return;
                    }
                });
            console.log(ws.name+' 离开，聊天室内共'+clients.length+'个人');
        });*/

        ws.on('close', function () { //给客户端对象绑定close事件，客户端关闭了
            broadcast0(ws.name+'离开聊天室', ws); //把客户端发送来的信息，广播给其它客户端。 

            clients = clients.filter(item => {
            return item != ws;
        });
        console.log(ws.name+' 离开，聊天室内共'+clients.length+'个人');
    });

});
    
//广播信息
function broadcast(msg, ws) {//broadcast是把信息发布（广播）给其它客户端
    clients.forEach(element => {    //clients: 记录着所有的客户端对象
        if(ws.name!='')
            element.send(ws.name + '说: ' + msg);    
    });
}

//广播信息-进出
function broadcast0(msg, ws) {//broadcast是把信息发布（广播）给其它客户端
    clients.forEach(element => {    //clients: 记录着所有的客户端对象
        if(ws.name!='')
            element.send(msg);    
    });
}

setInterval (function(){
    let dt=sd.format(new Date(),'YYYY-MM-DD HH:mm:ss');
    notifyTime(dt);
},1000);

function notifyTime(dt) {
    clients.forEach(element => {    //clients: 记录着所有的客户端对象
        element.send('currtime:'+dt);    
    });
}
